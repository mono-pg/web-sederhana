

const akses = (req,res,next) => {
    const user = req.session.user || "";
    const admin = req.session.admin || "";

    if(user){
        next()
    }else if(admin){
        next("route")
    }else {
        res.send("Login cuy <a href='/login'>Login</a>")
    }
}

export default akses