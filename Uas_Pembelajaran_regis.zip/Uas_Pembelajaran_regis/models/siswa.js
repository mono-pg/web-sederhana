import { sequelize,DataTypes } from "../db/db.js";

const siswa = sequelize.define('siswa',{
    nama : DataTypes.STRING,
    nim : DataTypes.STRING,
    alamat : DataTypes.STRING,
})

export default siswa;